angular.module('smartOCR', ['ngRoute', 'ui.grid'])
.config(['$routeProvider', function ($routeProvider) {
		$routeProvider
	.when('/', {
		templateUrl : 'partials/landing-page.html',
		controller: 'LandingController',
		controllerAs:'lcvm'
		
	})	
	.when('/multiOCR', {
		templateUrl : 'partials/multi-ocr-page.html',
		controller: 'MultiOcrController',
		controllerAs:'mocvm'
		
	})	
	.otherwise({redirectTo: '/'});
}])/*.directive("ocrSpinner",[function($compile, $http){
	 return{
         link: linkFunction
     };

     function linkFunction(scope, element, attrs) {
         scope.$on('start-spinner', function() {
            // var template = $compile('<div>hello spinner...spinna ll rthe way</div>')(scope);
             element.html($compile('<div>hello spinner...spinna ll rthe way</div>')(scope));
         });
         scope.$on('stop-spinner', function() {
             element.html($compile("<span></span>")(scope));
         });
     }
	
}])*/
/*.directive("fileread", [function () {
    return {
    	restrict: 'A',
    	scope:{
    		fileread : '='
    	},
    		
        link: function (scope, element, attributes) {
            element.bind("change", function (changeEvent) {
            	var counter = 0;
            	var picFiles = [];
            	var files = changeEvent.target.files; 
            	//var output = document.getElementById("result");
            	var carouselMainDiv = document.getElementById('carousel');
            	if(files.length){
            		$('#bn-item').removeClass("attach_button").addClass("btn-right");
            	}
				//output.value ="";	
                for (var i = 0; i < files.length; i++) {
					var file = files[i];
					if (!file.type.match('image')){
						continue;
					}
					 var reader = new FileReader();
					 
					 reader.onload = function (loadEvent) {
						 var picFile = loadEvent.target;
						 picFiles.push(picFile.result);
	                     var div = document.createElement("div")
	                     if(counter == 0){
	                       div.className = "item active";
	                       counter = 1;
	                     }else{
	                       div.className = "item";
	                     }
                       
	                    div.innerHTML = "<img src='"+picFile.result+"'/>";
	                    carouselMainDiv.insertBefore(div,null);
	                    scope.$apply(function () {
	                    	scope.fileread = picFiles;//loadEvent.target.result;
	                      });
		                }
			            reader.readAsDataURL(file);
                }
               
            });
        }
    }
}]);*/
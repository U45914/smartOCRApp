(function (){
	
	'use strict';
	
	 angular.module('smartOCR')
	 .controller('LandingController',LandingController);
	 
	 LandingController.$inject =['$scope','$location'];
	 
	 function LandingController($scope, $location){
		 
		 var lcvm=this;	
		 //$location.path = '/multiOCR'
		 
	}
	
})();
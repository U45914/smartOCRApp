(function(){
	'use strict';
	
	 angular.module('smartOCR')
	 .controller('PreProfilerViewController', PreProfilerViewController);
	 
	 PreProfilerViewController.$inject =['$scope','$rootScope', '$location','OCRServices'];
	 
	 function PreProfilerViewController($scope, $rootScope, $location, OCRServices){
		 
		 var ppvcvm = this;
		 ppvcvm.previewData = null;
		 
		 
		 
		 activate();
		 
		 function activate(){
			 ppvcvm.previewData = OCRServices.getPreviewData();		
				 
		 }		 
		 
		 
	 }
})();
(function() {

	'use strict';

	angular.module('smartOCR').factory('OCRServices', OCRServices);

	OCRServices.$inject = ['$http', '$rootScope'];

	function OCRServices($http, $rootScope) {
		
		var imageArray = [];
		var files = null;
		var previewData = null;
		
		var api = {
			postImageData : postImageData,
			getImageData : getImageData,
			/*getImageWithOCR : getImageWithOCR,
			getAttributes : getAttributes,*/
			/*extractAbzoobaResponse : extractAbzoobaResponse,
			postDataToEmiForCreation : postDataToEmiForCreation,*/
			pushToArray : pushToArray,
			getArray : getArray,
			initArray : initArray,
			setFiles : setFiles,
			getFiles : getFiles,
			setPreviewData : setPreviewData,
			getPreviewData : getPreviewData
		}

		return api;
		
		function pushToArray(imageData){
			imageArray.push(imageData);
		}
		
		function initArray(){
			imageArray = [];
		}
		
		function getArray(){
			return imageArray;
		}
		
		function setFiles(filesData){
			files = filesData;
		}
		
		function getFiles(){
			return files;
		}
		
		function setPreviewData(data){
			previewData = data;
		}
		
		function getPreviewData(){
			return previewData;
		}

		function postImageData(files) {
			return $http.post("https://product-profiling.herokuapp.com/rest/services/uploadImages", files, {
	            transformRequest: angular.identity,
	            headers: {'Content-Type': undefined}
	        }).then(onSuccessResponse, onErrorResponse);
		}
		
		function getImageData(id){
			var request = {
					method : 'GET',
					url : 'https://product-profiling.herokuapp.com/rest/services/images/'+ id,					
					headers: {
					    'Accept':'application/json'					    
					}
			};
			//return $http(request).then(onSuccessResponse, onErrorResponse);	
			return $http.get("json/previewData.json").then(onSuccessResponse, onErrorResponse);		
		}
		
		/*function extractAbzoobaResponse(jsonString){
			var request = {
				method : 'POST',
				url : 'rest/abzoobaParse/parseText',
				data: jsonString,
				headers: {
				    'Accept':'application/json',
				    'Content-Type': 'application/json'
				}
			}
			return $http(request).then(onSuccessResponse, onErrorResponse);			
		}
		
		function postDataToEmiForCreation(jsonString){
			var request ={
				method : 'POST',
				url : 'http://WVWEA004C2483.homeoffice.Wal-Mart.com:8888/OCRImageToText/rest/Product/create',
				data : jsonString,
				headers :{
					'Content-Type': 'application/json'
				}
			}
			return $http(request).then(onSuccessResponse, onErrorResponse);	
		}*/


		function onSuccessResponse(response) {
			return response;
		}

		function onErrorResponse(response) {
			console.log('Failed to load content'+ ' ' + response.statusText);
			toastr.error("Ooops !!! Something went wrong");
			$rootScope.$broadcast('stop-spinner');
		}

	}

})();